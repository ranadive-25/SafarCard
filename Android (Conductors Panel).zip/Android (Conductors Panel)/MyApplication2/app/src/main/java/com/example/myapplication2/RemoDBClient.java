package com.example.myapplication2;

public class RemoDBClient {

    private static final String REMODB_URL = "http://remodb.example.com";

}
